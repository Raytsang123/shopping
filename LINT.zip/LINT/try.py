from transformers import AutoTokenizer


tokenizer = AutoTokenizer.from_pretrained('/data/zengrui/generation_security/Llama-2-7B-chat', add_prefix_space=True)
