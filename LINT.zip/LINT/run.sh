
export CUDA_VISIBLE_DEVICES='2,3'

python lint/entrypoint.py --model 'llama2-7b'
